August 2017 data from: https://www.transtats.bts.gov/DL_SelectFields.asp?Table_ID=236

Fields:
* `FlightDate`: Flight Date (yyyymmdd)
* `UniqueCarrier`: See `L_UNIQUE_CARRIERS.csv`
* `FlightNum`: Flight number
* `OriginAirportID`: See `L_AIRPORT_ID.csv`
* `OriginCityMarketID`: See `L_CITY_MARKET_ID.csv`
* `DestAirportID`: See `L_AIRPORT_ID.csv`
* `DestCityMarketID`: See `L_CITY_MARKET_ID.csv`
